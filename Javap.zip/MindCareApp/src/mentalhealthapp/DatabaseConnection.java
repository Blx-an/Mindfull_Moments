
package mentalhealthapp;

import java.sql.*;
import javax.swing.*;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/mentalhealth";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "MYS3LF@mys3lf"; // Change to your MySQL password
    
    private Connection connection;
    
    public DatabaseConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Attempting to connect to the database...");
            this.connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            
            // ✅ ADDED SUCCESS CODE HERE
            if (this.connection != null) {
                System.out.println("✅ Database connection successful!");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, 
                "Database connection failed!\nPlease make sure MySQL is running and database exists.", 
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public Connection getConnection() {
        return connection;

    }
    
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}