package mentalhealthapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class AdminDashboard extends JFrame {
    private UserRepository userRepository;
    private MoodRepository moodRepository;
    private JournalRepository journalRepository;
    
    private final Color BACKGROUND_COLOR = new Color(249, 250, 251);
    private final Color CARD_COLOR = Color.WHITE;
    private final Color PRIMARY_COLOR = new Color(102, 126, 234);
    
    public AdminDashboard(UserRepository userRepo, MoodRepository moodRepo, JournalRepository journalRepo) {
        this.userRepository = userRepo;
        this.moodRepository = moodRepo;
        this.journalRepository = journalRepo;
        
        setTitle("👨‍💼 Admin Dashboard - User Management");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND_COLOR);
        
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        tabbedPane.addTab("👥 Users Overview", createUsersOverviewPanel());
        tabbedPane.addTab("😊 All Mood Entries", createAllMoodsPanel());
        tabbedPane.addTab("📔 All Journals", createAllJournalsPanel());
        tabbedPane.addTab("📊 Analytics", createAnalyticsPanel());
        
        add(tabbedPane);
    }
    
    private JPanel createUsersOverviewPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Get users from database
        java.util.List<User> users = userRepository.getAllUsers();
        
        // Header with stats
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(BACKGROUND_COLOR);
        
        JLabel titleLabel = new JLabel("👥 User Management Dashboard");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(PRIMARY_COLOR);
        
        // Stats cards
        JPanel statsPanel = new JPanel(new GridLayout(1, 4, 15, 0));
        statsPanel.setBackground(BACKGROUND_COLOR);
        statsPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        int totalUsers = users.size();
        int activeUsers = (int) users.stream()
            .filter(user -> !user.getMoodHistory().isEmpty() || !user.getJournalEntries().isEmpty())
            .count();
        int totalMoods = users.stream().mapToInt(user -> user.getMoodHistory().size()).sum();
        int totalJournals = users.stream().mapToInt(user -> user.getJournalEntries().size()).sum();
        
        statsPanel.add(createStatCard("Total Users", String.valueOf(totalUsers), "👥", new Color(102, 126, 234)));
        statsPanel.add(createStatCard("Active Users", String.valueOf(activeUsers), "✅", new Color(74, 222, 128)));
        statsPanel.add(createStatCard("Mood Entries", String.valueOf(totalMoods), "😊", new Color(248, 113, 113)));
        statsPanel.add(createStatCard("Journals", String.valueOf(totalJournals), "📔", new Color(251, 146, 60)));
        
        headerPanel.add(titleLabel, BorderLayout.NORTH);
        headerPanel.add(statsPanel, BorderLayout.SOUTH);
        
        // Users table
        String[] columns = {"Name", "Email", "Mood Entries", "Journal Entries", "Self-Test Score"};
        Object[][] data = new Object[users.size()][5];
        
        for (int i = 0; i < users.size(); i++) {
            User user = users.get(i);
            data[i][0] = user.getName();
            data[i][1] = user.getEmail();
            data[i][2] = user.getMoodHistory().size();
            data[i][3] = user.getJournalEntries().size();
            data[i][4] = user.getSelfTestScore() + " - " + user.getSelfTestResult();
        }
        
        JTable table = new JTable(data, columns);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.setShowGrid(true);
        table.setGridColor(new Color(229, 231, 235));
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder("User Details (" + users.size() + " users)"));
        
        // Action buttons
        JPanel actionPanel = new JPanel(new FlowLayout());
        actionPanel.setBackground(BACKGROUND_COLOR);
        actionPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        
        JButton refreshBtn = createActionButton("🔄 Refresh Data", PRIMARY_COLOR);
        JButton statsBtn = createActionButton("📈 Show Statistics", new Color(74, 222, 128));
        
        refreshBtn.addActionListener(e -> {
            dispose();
            new AdminDashboard(userRepository, moodRepository, journalRepository).setVisible(true);
        });
        statsBtn.addActionListener(e -> showStatistics(users));
        
        actionPanel.add(refreshBtn);
        actionPanel.add(statsBtn);
        
        panel.add(headerPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(actionPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createStatCard(String title, String value, String emoji, Color color) {
        JPanel card = new JPanel();
        card.setBackground(CARD_COLOR);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(229, 231, 235)),
            BorderFactory.createEmptyBorder(20, 15, 20, 15)
        ));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        
        JLabel emojiLabel = new JLabel(emoji);
        emojiLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 24));
        emojiLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        valueLabel.setForeground(color);
        valueLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        titleLabel.setForeground(Color.GRAY);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        card.add(emojiLabel);
        card.add(Box.createRigidArea(new Dimension(0, 5)));
        card.add(valueLabel);
        card.add(Box.createRigidArea(new Dimension(0, 5)));
        card.add(titleLabel);
        
        return card;
    }
    
    private JButton createActionButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    private JPanel createAllMoodsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Get all mood entries from database
        java.util.List<Object[]> allMoods = moodRepository.getAllMoodEntries();
        
        String[] columns = {"User Name", "Email", "Date", "Mood", "Notes"};
        Object[][] data = allMoods.toArray(new Object[0][0]);
        
        JTable table = createStyledTable(data, columns);
        JScrollPane scrollPane = new JScrollPane(table);
        
        JLabel countLabel = new JLabel("📊 Total Mood Entries: " + allMoods.size(), JLabel.CENTER);
        countLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        countLabel.setForeground(PRIMARY_COLOR);
        countLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        panel.add(countLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createAllJournalsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Get all journal entries from database
        java.util.List<Object[]> allJournals = journalRepository.getAllJournalEntries();
        
        String[] columns = {"User Name", "Date", "Title", "Content Preview"};
        Object[][] data = allJournals.toArray(new Object[0][0]);
        
        JTable table = createStyledTable(data, columns);
        JScrollPane scrollPane = new JScrollPane(table);
        
        JLabel countLabel = new JLabel("📔 Total Journal Entries: " + allJournals.size(), JLabel.CENTER);
        countLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        countLabel.setForeground(PRIMARY_COLOR);
        countLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        panel.add(countLabel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createAnalyticsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JTextArea analyticsArea = new JTextArea();
        analyticsArea.setEditable(false);
        analyticsArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        analyticsArea.setBackground(CARD_COLOR);
        analyticsArea.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Get users from database for analytics
        java.util.List<User> users = userRepository.getAllUsers();
        
        // Calculate analytics
        int totalUsers = users.size();
        int totalMoodEntries = users.stream().mapToInt(user -> user.getMoodHistory().size()).sum();
        int totalJournalEntries = users.stream().mapToInt(user -> user.getJournalEntries().size()).sum();
        
        // Mood distribution
        Map<String, Integer> moodDistribution = new HashMap<>();
        for (User user : users) {
            for (MoodEntry mood : user.getMoodHistory()) {
                moodDistribution.put(mood.getMood(), moodDistribution.getOrDefault(mood.getMood(), 0) + 1);
            }
        }
        
        // Build analytics text
        StringBuilder analyticsText = new StringBuilder();
        analyticsText.append("📈 MENTAL HEALTH APP ANALYTICS\n\n");
        analyticsText.append("👥 Total Registered Users: ").append(totalUsers).append("\n");
        analyticsText.append("😊 Total Mood Entries: ").append(totalMoodEntries).append("\n");
        analyticsText.append("📔 Total Journal Entries: ").append(totalJournalEntries).append("\n\n");
        
        analyticsText.append("📊 MOOD DISTRIBUTION:\n");
        analyticsText.append("--------------------\n");
        for (Map.Entry<String, Integer> entry : moodDistribution.entrySet()) {
            analyticsText.append(entry.getKey()).append(": ").append(entry.getValue()).append(" entries\n");
        }
        
        analyticsText.append("\n📋 USER ACTIVITY SUMMARY:\n");
        analyticsText.append("-----------------------\n");
        for (User user : users) {
            analyticsText.append(user.getName()).append(" (").append(user.getEmail()).append("):\n");
            analyticsText.append("  - Mood entries: ").append(user.getMoodHistory().size()).append("\n");
            analyticsText.append("  - Journal entries: ").append(user.getJournalEntries().size()).append("\n");
            analyticsText.append("  - Self-test: ").append(user.getSelfTestScore()).append("/24 - ").append(user.getSelfTestResult()).append("\n\n");
        }
        
        analyticsArea.setText(analyticsText.toString());
        
        panel.add(new JScrollPane(analyticsArea), BorderLayout.CENTER);
        
        return panel;
    }
    
    private JTable createStyledTable(Object[][] data, String[] columns) {
        JTable table = new JTable(data, columns);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        table.setShowGrid(true);
        table.setGridColor(new Color(229, 231, 235));
        return table;
    }
    
    private void showStatistics(java.util.List<User> users) {
        int activeUsers = (int) users.stream()
            .filter(user -> !user.getMoodHistory().isEmpty() || !user.getJournalEntries().isEmpty())
            .count();
        
        String stats = String.format(
            "📊 App Statistics:\n\n" +
            "👥 Total Users: %d\n" +
            "✅ Active Users: %d\n" +
            "❌ Inactive Users: %d\n\n" +
            "😊 Average Mood Entries per User: %.1f\n" +
            "📔 Average Journal Entries per User: %.1f",
            users.size(),
            activeUsers,
            users.size() - activeUsers,
            users.stream().mapToInt(user -> user.getMoodHistory().size()).average().orElse(0),
            users.stream().mapToInt(user -> user.getJournalEntries().size()).average().orElse(0)
        );
        
        JOptionPane.showMessageDialog(this, stats, "📈 App Statistics", JOptionPane.INFORMATION_MESSAGE);
    }
}
