package mentalhealthapp;

import java.sql.*;

public class SelfTestRepository {
    private DatabaseConnection dbConnection;
    
    public SelfTestRepository() {
        this.dbConnection = new DatabaseConnection();
    }
    
    public boolean saveSelfTestResult(String userEmail, int totalScore, String resultCategory) {
        String sql = "INSERT INTO self_tests (user_id, total_score, result_category) " +
                    "VALUES ((SELECT user_id FROM users WHERE email = ?), ?, ?)";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, userEmail);
            stmt.setInt(2, totalScore);
            stmt.setString(3, resultCategory);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    } // <--- ADD THIS CLOSING BRACE for saveSelfTestResult
} // <--- This closes the class