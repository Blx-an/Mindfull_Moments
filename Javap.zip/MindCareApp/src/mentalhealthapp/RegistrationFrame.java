package mentalhealthapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class RegistrationFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    
    private UserRepository userRepository;

    private final Color BACKGROUND_COLOR = new Color(245, 247, 255);
    private final Color PRIMARY_COLOR = new Color(102, 126, 234);

    public RegistrationFrame(UserRepository repo) {
        this.userRepository = repo;

        setTitle("✨ Register New Account");
        setSize(400, 380); // Increased size to fit the role combo box
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND_COLOR);
        setLayout(new BorderLayout(10, 10));

        // Use 7 rows for Name, Email, Password, Role, and spacing
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formPanel.setBackground(BACKGROUND_COLOR);

        // Input Fields
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        
        // Role Selection (Keeping this element for the handleRegistration fix)
        String[] roles = {"User", "Admin"};
        JComboBox<String> roleCombo = new JComboBox<>(roles);
        // By default, only 'User' should be available on a public registration page
        // You can hide the JComboBox or remove it if you only want to register 'User'
        
        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Email:"));
        formPanel.add(emailField);
        formPanel.add(new JLabel("Password:"));
        formPanel.add(passwordField);
        
        // Temporarily keep the role input to match the constructor size from prior versions
        formPanel.add(new JLabel("Role (Defaults to User):"));
        formPanel.add(roleCombo);

        JButton registerBtn = createStyledButton("📝 Register", PRIMARY_COLOR);
        // ⭐ FIX 2: Pass all arguments collected from the form
        registerBtn.addActionListener(e -> handleRegistration(nameField, emailField, passwordField, roleCombo)); 
        
        add(formPanel, BorderLayout.CENTER);
        add(registerBtn, BorderLayout.SOUTH);
    }
    
    // ⭐ FIX 1: Add the missing createStyledButton method
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    // ⭐ FIX 2: Corrected method signature to accept JComboBox<String>
    private void handleRegistration(JTextField nameField, JTextField emailField, JPasswordField passwordField, JComboBox<String> roleCombo) {
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword());
        
        // Since you want only 3 parameters to userRepository, we ignore the JComboBox value
        String role = (String) roleCombo.getSelectedItem(); 

        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Please fill in all fields.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Call registerUser with 3 parameters (Name, Email, Password)
        // Ensure your UserRepository has this 3-parameter method signature.
        boolean success = userRepository.registerUser(name, email, password); 
        
        if (success) {
            JOptionPane.showMessageDialog(this, 
                "✅ Registration successful for User! You can now log in.", 
                "Success", JOptionPane.INFORMATION_MESSAGE);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, 
                "❌ Registration failed. The email may already be in use or connection failed.", 
                "Failure", JOptionPane.ERROR_MESSAGE);
        }
    }
}