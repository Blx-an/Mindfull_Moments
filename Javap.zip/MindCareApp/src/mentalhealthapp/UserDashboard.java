package mentalhealthapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.util.*;
// Ensure MoodEntry and JournalEntry are imported correctly from the package

public class UserDashboard extends JFrame {
    private static final long serialVersionUID = 1L; 
 
 	private User user;
 	private UserRepository userRepository;
    private MoodRepository moodRepository;
    private JournalRepository journalRepository;
    private SelfTestRepository selfTestRepository;
    
    private final Color BACKGROUND_COLOR = new Color(245, 247, 255);
    private final Color CARD_COLOR = Color.WHITE;
    private final Color PRIMARY_COLOR = new Color(102, 126, 234);
    
    public UserDashboard(User user, UserRepository userRepo, MoodRepository moodRepo, 
                        JournalRepository journalRepo, SelfTestRepository testRepo) {
        this.user = user;
        this.userRepository = userRepo;
        this.moodRepository = moodRepo;
        this.journalRepository = journalRepo;
        this.selfTestRepository = testRepo;
        
        setTitle("🧘 Dashboard - " + user.getName());
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND_COLOR);
        
        // Load initial data from database
        loadUserDataFromDatabase();
        
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        tabbedPane.addTab("😊 Mood Tracker", createMoodTrackerPanel());
        tabbedPane.addTab("📔 Well-being Journal", createJournalPanel());
        tabbedPane.addTab("📚 Resources", createResourcesPanel());
        tabbedPane.addTab("🧘 Relaxation", createRelaxationPanel());
        tabbedPane.addTab("📝 Self Test", createSelfTestPanel());
        
        add(tabbedPane);
    }
    
    private void loadUserDataFromDatabase() {
        // Reload user data from database to get latest entries
        // NOTE: This requires User.getPassword() to be defined and set after login!
        User freshUserData = userRepository.findByEmailAndPassword(user.getEmail(), user.getPassword());
        if (freshUserData != null) {
            // Preserve the password set during login before updating
            String currentPassword = user.getPassword();

            // Update the current user object with fresh data
            user.getMoodHistory().clear();
            user.getMoodHistory().addAll(freshUserData.getMoodHistory());
            
            user.getJournalEntries().clear();
            user.getJournalEntries().addAll(freshUserData.getJournalEntries());
            
            user.setSelfTestScore(freshUserData.getSelfTestScore());
            user.setSelfTestResult(freshUserData.getSelfTestResult());

            // Re-set the password field since the User constructor doesn't handle it
            user.setPassword(currentPassword);
        }
    }
    
    private JPanel createMoodTrackerPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Input form
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBackground(BACKGROUND_COLOR);
        formPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        formPanel.add(new JLabel("Date:"));
        JTextField dateField = new JTextField(LocalDate.now().toString());
        formPanel.add(dateField);
        
        formPanel.add(new JLabel("Mood:"));
        String[] moods = {"😊 Happy", "😢 Sad", "😰 Anxious", "😌 Calm", "😫 Stressed", "😐 Neutral"};
        JComboBox<String> moodCombo = new JComboBox<>(moods);
        formPanel.add(moodCombo);
        
        formPanel.add(new JLabel("Notes:"));
        JTextField notesField = new JTextField();
        formPanel.add(notesField);
        
        JButton addBtn = createStyledButton("➕ Add Mood Entry", PRIMARY_COLOR);
        addBtn.addActionListener(e -> {
            String date = dateField.getText();
            String mood = (String) moodCombo.getSelectedItem();
            String notes = notesField.getText();
            
            if (!date.isEmpty()) {
                MoodEntry newEntry = new MoodEntry(date, mood, notes);
                if (moodRepository.addMoodEntry(user.getEmail(), newEntry)) {
                    // Refresh user data from database
                    loadUserDataFromDatabase();
                    JOptionPane.showMessageDialog(this, "😊 Mood entry added successfully!");
                    notesField.setText("");
                    refreshMoodTable(panel);
                } else {
                    JOptionPane.showMessageDialog(this, "❌ Failed to save mood entry!");
                }
            } else {
                JOptionPane.showMessageDialog(this, "⚠️ Please enter a date!");
            }
        });
        formPanel.add(addBtn);
        
        panel.add(formPanel, BorderLayout.NORTH);
        
        // Mood history table
        refreshMoodTable(panel);
        
        return panel;
    }
    
    private void refreshMoodTable(JPanel panel) {
        // Remove existing table if any
        Component[] components = panel.getComponents();
        for (Component comp : components) {
            if (comp instanceof JScrollPane) {
                panel.remove(comp);
            }
        }
        
        // Create new table
        String[] columns = {"Date", "Mood", "Notes"};
        Object[][] data = new Object[user.getMoodHistory().size()][3];
        for (int i = 0; i < user.getMoodHistory().size(); i++) {
            MoodEntry entry = user.getMoodHistory().get(i);
            data[i][0] = entry.getDate();
            data[i][1] = entry.getMood();
            data[i][2] = entry.getNotes();
        }
        
        JTable table = new JTable(data, columns);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder("📊 Your Mood History (" + user.getMoodHistory().size() + " entries)"));
        
        panel.add(scrollPane, BorderLayout.CENTER);
        
        panel.revalidate();
        panel.repaint();
    }
    
    private JPanel createJournalPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Input form
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBackground(BACKGROUND_COLOR);
        formPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        formPanel.add(new JLabel("Date:"));
        JTextField dateField = new JTextField(LocalDate.now().toString());
        formPanel.add(dateField);
        
        formPanel.add(new JLabel("Title:"));
        JTextField titleField = new JTextField();
        formPanel.add(titleField);
        
        formPanel.add(new JLabel("Content:"));
        JTextArea contentArea = new JTextArea(3, 20);
        JScrollPane contentScroll = new JScrollPane(contentArea);
        formPanel.add(contentScroll);
        
        JButton addBtn = createStyledButton("➕ Add Journal Entry", PRIMARY_COLOR);
        addBtn.addActionListener(e -> {
            String date = dateField.getText();
            String title = titleField.getText();
            String content = contentArea.getText();
            
            if (!date.isEmpty() && !title.isEmpty()) {
                JournalEntry newEntry = new JournalEntry(date, title, content);
                if (journalRepository.addJournalEntry(user.getEmail(), newEntry)) {
                    // Refresh user data from database
                    loadUserDataFromDatabase();
                    JOptionPane.showMessageDialog(this, "📔 Journal entry added successfully!");
                    titleField.setText("");
                    contentArea.setText("");
                    refreshJournalTable(panel);
                } else {
                    JOptionPane.showMessageDialog(this, "❌ Failed to save journal entry!");
                }
            } else {
                JOptionPane.showMessageDialog(this, "⚠️ Please fill all fields!");
            }
        });
        formPanel.add(addBtn);
        
        panel.add(formPanel, BorderLayout.NORTH);
        
        // Journal history table
        refreshJournalTable(panel);
        
        return panel;
    }
    
    private void refreshJournalTable(JPanel panel) {
        // Remove existing table if any
        Component[] components = panel.getComponents();
        for (Component comp : components) {
            if (comp instanceof JScrollPane) {
                panel.remove(comp);
            }
        }
        
        // Create new table
        String[] columns = {"Date", "Title", "Content Preview"};
        Object[][] data = new Object[user.getJournalEntries().size()][3];
        for (int i = 0; i < user.getJournalEntries().size(); i++) {
            JournalEntry entry = user.getJournalEntries().get(i);
            data[i][0] = entry.getDate();
            data[i][1] = entry.getTitle();
            String preview = entry.getContent().length() > 50 ? 
                entry.getContent().substring(0, 50) + "..." : entry.getContent();
            data[i][2] = preview;
        }
        
        JTable table = new JTable(data, columns);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder("📖 Your Journal Entries (" + user.getJournalEntries().size() + " entries)"));
        
        panel.add(scrollPane, BorderLayout.CENTER);
        
        panel.revalidate();
        panel.repaint();
    }
    
    private JPanel createResourcesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel titleLabel = new JLabel("📚 Mental Health Resources", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(PRIMARY_COLOR);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        String[] resources = {
            "📚 Understanding Anxiety - Learn about anxiety symptoms and coping strategies",
            "🧘 Breathing Exercises - Simple techniques to calm your mind",
            "📖 Mindfulness Guide - How to practice mindfulness in daily life",
            "💪 Stress Management - Tips for managing stress effectively",
            "🛌 Sleep Hygiene - Improve your sleep quality",
            "🎯 Goal Setting - Set achievable mental health goals"
        };
        
        JList<String> resourceList = new JList<>(resources);
        resourceList.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        resourceList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        resourceList.setBackground(CARD_COLOR);
        resourceList.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JButton viewBtn = createStyledButton("👁️ View Resource Details", PRIMARY_COLOR);
        viewBtn.addActionListener(e -> {
            int index = resourceList.getSelectedIndex();
            if (index >= 0) {
                String[] content = {
                    "Anxiety is a normal emotion that everyone experiences. Symptoms include: rapid heartbeat, sweating, feeling tense. Coping strategies: deep breathing, exercise, talking to someone.",
                    "4-7-8 Breathing: Inhale for 4 seconds, hold for 7 seconds, exhale for 8 seconds. Repeat 5 times.",
                    "Mindfulness means paying attention to the present moment without judgment. Practice by focusing on your breath for 5 minutes daily.",
                    "Stress management techniques: regular exercise, healthy eating, adequate sleep, time management, and relaxation exercises.",
                    "Good sleep habits: consistent sleep schedule, avoid screens before bed, comfortable room temperature, and relaxing bedtime routine.",
                    "Set SMART goals: Specific, Measurable, Achievable, Relevant, Time-bound. Start small and celebrate progress."
                };
                
                JTextArea textArea = new JTextArea(content[index], 10, 40);
                textArea.setWrapStyleWord(true);
                textArea.setLineWrap(true);
                textArea.setEditable(false);
                textArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
                
                JOptionPane.showMessageDialog(this, new JScrollPane(textArea), 
                    resources[index].split(" - ")[0], JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "⚠️ Please select a resource first!");
            }
        });
        
        panel.add(new JScrollPane(resourceList), BorderLayout.CENTER);
        panel.add(viewBtn, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createRelaxationPanel() {
        JPanel panel = new JPanel(new GridLayout(2, 2, 15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(BACKGROUND_COLOR);
        
        JButton breathingBtn = createExerciseButton("🌬️ Breathing Exercise", 
            "4-7-8 Breathing Technique:\n\n• Inhale through nose for 4 seconds\n• Hold breath for 7 seconds\n• Exhale through mouth for 8 seconds\n• Repeat 5-10 times");
        
        JButton meditationBtn = createExerciseButton("🧘 5-Minute Meditation", 
            "Quick Meditation:\n\n• Find quiet space\n• Sit comfortably\n• Focus on your breath\n• Notice thoughts without judgment\n• Return focus to breath");
        
        JButton muscleBtn = createExerciseButton("💪 Muscle Relaxation", 
            "Progressive Muscle Relaxation:\n\n• Tense each muscle group for 5 seconds\n• Release and relax for 30 seconds\n• Start from toes, move upward\n• End with facial muscles");
        
        JButton mindfulnessBtn = createExerciseButton("🌟 Mindfulness", 
            "Mindfulness Practice:\n\n• Notice 5 things you can see\n• Notice 4 things you can touch\n• Notice 3 things you can hear\n• Notice 2 things you can smell\n• Notice 1 thing you can taste");
        
        panel.add(breathingBtn);
        panel.add(meditationBtn);
        panel.add(muscleBtn);
        panel.add(mindfulnessBtn);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BACKGROUND_COLOR);
        
        JLabel titleLabel = new JLabel("🧘 Relaxation Exercises", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(PRIMARY_COLOR);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        mainPanel.add(titleLabel, BorderLayout.NORTH);
        mainPanel.add(panel, BorderLayout.CENTER);
        
        return mainPanel;
    }
    
    private JButton createExerciseButton(String title, String instructions) {
        JButton button = new JButton("<html><center>" + title + "</center></html>");
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addActionListener(e -> {
            JTextArea textArea = new JTextArea(instructions, 10, 30);
            textArea.setEditable(false);
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
            textArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            JOptionPane.showMessageDialog(this, new JScrollPane(textArea), 
                title, JOptionPane.INFORMATION_MESSAGE);
        });
        
        return button;
    }
    
    private JPanel createSelfTestPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel titleLabel = new JLabel("📝 Mental Health Self-Assessment", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        titleLabel.setForeground(PRIMARY_COLOR);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        JTextArea infoArea = new JTextArea(
            "This self-assessment is based on common mental health indicators.\n\n" +
            "Rate how often you've experienced each of the following over the past 2 weeks:\n" +
            "0 - Not at all\n1 - Several days\n2 - More than half the days\n3 - Nearly every day\n\n" +
            "Your previous test: " + user.getSelfTestScore() + "/24 - " + user.getSelfTestResult()
        );
        infoArea.setEditable(false);
        infoArea.setBackground(BACKGROUND_COLOR);
        infoArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        infoArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(new JScrollPane(infoArea), BorderLayout.CENTER);
        
        JButton startTestBtn = createStyledButton("🎯 Start Self-Test", PRIMARY_COLOR);
        startTestBtn.addActionListener(e -> showSelfTestQuestions());
        panel.add(startTestBtn, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private void showSelfTestQuestions() {
        String[] questions = {
            "Little interest or pleasure in doing things?",
            "Feeling down, depressed, or hopeless?",
            "Trouble falling or staying asleep, or sleeping too much?",
            "Feeling tired or having little energy?",
            "Poor appetite or overeating?",
            "Feeling bad about yourself - or that you are a failure?",
            "Trouble concentrating on things?",
            "Moving or speaking slowly? Or being fidgety/restless?"
        };
        
        int totalScore = 0;
        
        for (int i = 0; i < questions.length; i++) {
            Object[] options = {"0 - Not at all", "1 - Several days", "2 - More than half the days", "3 - Nearly every day"};
            int response = JOptionPane.showOptionDialog(this, 
                "Question " + (i + 1) + " of " + questions.length + ":\n" + questions[i],
                "Self-Test",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);
            
            if (response == JOptionPane.CLOSED_OPTION) {
                return; // User cancelled
            }
            
            totalScore += response;
        }
        
        // Determine result
        String result;
        if (totalScore <= 4) {
            result = "Minimal symptoms";
        } else if (totalScore <= 9) {
            result = "Mild symptoms";
        } else if (totalScore <= 14) {
            result = "Moderate symptoms";
        } else {
            result = "Severe symptoms";
        }
        
        // Save to database
        if (selfTestRepository.saveSelfTestResult(user.getEmail(), totalScore, result)) {
            // Update user object
            user.setSelfTestScore(totalScore);
            user.setSelfTestResult(result);
            
            JOptionPane.showMessageDialog(this, 
                "Your score: " + totalScore + "/24\n\nResult: " + result + 
                "\n\nRemember: This is not a diagnosis. Consult a healthcare professional for proper assessment.",
                "🎯 Test Results", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Failed to save test results. Please try again.",
                "❌ Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
}