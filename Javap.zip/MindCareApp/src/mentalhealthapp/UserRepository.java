package mentalhealthapp;

import java.sql.*;
import java.util.*;

public class UserRepository {
    private DatabaseConnection dbConnection;
    
    public UserRepository() {
        this.dbConnection = new DatabaseConnection();
    }
    
    // --- LOGIN METHOD ---
    public User findByEmailAndPassword(String email, String password) {
        String sql = "SELECT user_id, name, email FROM users WHERE email = ? AND password = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            System.out.println("DEBUG: Attempting user login for: " + email);
            stmt.setString(1, email);
            stmt.setString(2, password);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                User user = new User(
                    rs.getInt("user_id"), 
                    rs.getString("name"),
                    rs.getString("email")
                );
                
                loadUserData(user, rs.getInt("user_id"), conn); 
                System.out.println("DEBUG: Login SUCCESS for: " + email);
                return user;
            }
        } catch (SQLException e) {
            System.err.println("SQL ERROR during user login: " + e.getMessage());
            e.printStackTrace();
        }
        System.out.println("DEBUG: Login FAILED for: " + email);
        return null;
    }
    
    // --- REGISTRATION METHOD ---
    public boolean createUser(String name, String email, String password) {
        String sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, password);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("SQL ERROR during registration: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // --- EMAIL EXISTS METHOD ---
    public boolean emailExists(String email) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT user_id, name, email FROM users";
        
        try (Connection conn = dbConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                User user = new User(
                    rs.getInt("user_id"),
                    rs.getString("name"),
                    rs.getString("email")
                );
                loadUserData(user, rs.getInt("user_id"), conn);
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }
    
    // --- DATA LOADING METHOD ---
    private void loadUserData(User user, int userId, Connection conn) throws SQLException {
        // Load mood entries
        String moodSql = "SELECT date, mood, notes FROM moodentries WHERE user_id = ? ORDER BY date DESC";
        try (PreparedStatement stmt = conn.prepareStatement(moodSql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                user.getMoodHistory().add(new MoodEntry(
                    rs.getString("date"),
                    rs.getString("mood"),
                    rs.getString("notes")
                ));
            }
        }
        
        // Load journal entries
        String journalSql = "SELECT date, title, content FROM journalentries WHERE user_id = ? ORDER BY date DESC";
        try (PreparedStatement stmt = conn.prepareStatement(journalSql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                user.getJournalEntries().add(new JournalEntry(
                    rs.getString("date"),
                    rs.getString("title"),
                    rs.getString("content")
                ));
            }
        }
        
        // Load latest self-test
        String testSql = "SELECT total_score, result_category FROM self_tests WHERE user_id = ? ORDER BY test_date DESC LIMIT 1";
        try (PreparedStatement stmt = conn.prepareStatement(testSql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                user.setSelfTestScore(rs.getInt("total_score"));
                user.setSelfTestResult(rs.getString("result_category"));
            }
        }
    }

 // Inside UserRepository.java

    public boolean registerUser(String name, String email, String password) {
        // 1. Check if the email already exists to prevent duplication
        if (emailExists(email)) {
            System.err.println("❌ Registration failed: Email '" + email + "' is already in use.");
            return false;
        }
        
        // 2. Call the createUser method (which executes the SQL INSERT)
        boolean success = createUser(name, email, password);
        
        if (success) {
            System.out.println("✅ New User registered: " + email);
        }
        
        // 3. Return the result of the database operation
        return success;
    }
}