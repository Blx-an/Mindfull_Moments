
package mentalhealthapp;

import java.util.ArrayList;
import java.util.List;

public class User {
    private int userId;
    private String name;
    private String email;
    // CRITICAL FIELD: Used by Dashboard to reload data
    private String password; 
    private List<MoodEntry> moodHistory;
    private List<JournalEntry> journalEntries;
    private int selfTestScore;
    private String selfTestResult;
    
    // Required Constructor
    public User(int userId, String name, String email) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.moodHistory = new ArrayList<>();
        this.journalEntries = new ArrayList<>();
        this.selfTestScore = 0;
        this.selfTestResult = "N/A"; 
        this.password = null; // Should be set after login or retrieved from DB by Repo
    }
    
    // --- Getters and Setters (REQUIRED FOR DASHBOARD/REPOSITORY) ---
    
    public int getUserId() { return userId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    
    // ⭐ FIX 1: Accessor for the password field
    public String getPassword() { return password; }
    
    // ⭐ FIX 2: Mutator for the password field (used in loadUserDataFromDatabase and LoginFrame)
    public void setPassword(String password) { this.password = password; }
    
    // ⭐ FIX 3: Accessors for Self-Test fields (needed for display in createSelfTestPanel)
    public int getSelfTestScore() { return selfTestScore; }
    public String getSelfTestResult() { return selfTestResult; } 
    
    public List<MoodEntry> getMoodHistory() { return moodHistory; }
    public List<JournalEntry> getJournalEntries() { return journalEntries; }
    
    // Mutators for Self-Test fields (needed for update after test)
    public void setSelfTestScore(int score) { this.selfTestScore = score; }
    public void setSelfTestResult(String result) { this.selfTestResult = result; }
}