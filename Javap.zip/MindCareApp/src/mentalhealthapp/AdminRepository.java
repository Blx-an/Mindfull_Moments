package mentalhealthapp;

import java.sql.*;

public class AdminRepository {
    private DatabaseConnection dbConnection;
    
    public AdminRepository() {
        this.dbConnection = new DatabaseConnection();
    }
    
    public boolean validateAdmin(String email, String password) {
        String sql = "SELECT COUNT(*) FROM admins WHERE email = ? AND password = ?";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            stmt.setString(2, password);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}