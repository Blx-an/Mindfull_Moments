
package mentalhealthapp;

public class MoodEntry {
    private String date;
    private String mood;
    private String notes;

    /**
     * FIX: This public constructor must be present to resolve the error.
     */
    public MoodEntry(String date, String mood, String notes) { 
        this.date = date;
        this.mood = mood;
        this.notes = notes;
    }

    // You also need the getters that were discussed previously:
    public String getMood() {
        return mood;
    }
    
    public String getDate() {
        return date;
    }
    
    public String getNotes() {
        return notes;
    }

    // ... any other methods ...
}