package mentalhealthapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;

public class LoginFrame extends JFrame {
    private UserRepository userRepository;
    private AdminRepository adminRepository;
    private JTextField emailField; 
    private JPasswordField passwordField;
    
    // Color scheme
    private final Color PRIMARY_COLOR = new Color(102, 126, 234);
    private final Color SECONDARY_COLOR = new Color(147, 165, 242);
    private final Color BACKGROUND_COLOR = new Color(245, 247, 255);
    private final Color ACCENT_COLOR = new Color(74, 222, 128);
    
    public LoginFrame(UserRepository userRepository, AdminRepository adminRepository) {
        this.userRepository = userRepository;
        this.adminRepository = adminRepository;
        
        setTitle("🌿 Mental Health App - Login");
        setSize(450, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND_COLOR);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BACKGROUND_COLOR);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        
        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(BACKGROUND_COLOR);
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        
        JLabel emojiLabel = new JLabel("💚", JLabel.CENTER);
        emojiLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 48));
        emojiLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel titleLabel = new JLabel("Mindful Moments", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(PRIMARY_COLOR);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel subtitleLabel = new JLabel("Your Mental Wellness Companion", JLabel.CENTER);
        subtitleLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        subtitleLabel.setForeground(Color.GRAY);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        headerPanel.add(emojiLabel);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        headerPanel.add(titleLabel);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        headerPanel.add(subtitleLabel);
        headerPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        
        // Form Panel
        JPanel formPanel = new JPanel();
        formPanel.setBackground(BACKGROUND_COLOR);
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        
        // Email Field
        JPanel emailPanel = createInputField("📧 Email:", new JTextField(20));
        formPanel.add(emailPanel);
        formPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        
        // Password Field
        JPanel passwordPanel = createInputField("🔒 Password:", new JPasswordField(20));
        formPanel.add(passwordPanel);
        formPanel.add(Box.createRigidArea(new Dimension(0, 25)));
        
        // Buttons Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        buttonPanel.setLayout(new GridLayout(3, 1, 10, 10));
        
        JButton userLoginBtn = createStyledButton("🧘 User Login", PRIMARY_COLOR);
        JButton adminLoginBtn = createStyledButton("👨‍💼 Admin Login", SECONDARY_COLOR);
        JButton registerBtn = createStyledButton("✨ Register New User", ACCENT_COLOR);
     // Original/Problematic code:
     // JTextField emailField = (JTextField) emailPanel.getComponent(1);
     // JPasswordField passwordField = (JPasswordField) ((JPanel) passwordPanel.getComponent(1)).getComponent(0);
        // User Login Action
        userLoginBtn.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());
            
            // Query database for user
            User user = userRepository.findByEmailAndPassword(email, password);
            if (user != null) {
                dispose();
                // Initialize all repositories for the dashboard
                MoodRepository moodRepo = new MoodRepository();
                JournalRepository journalRepo = new JournalRepository();
                SelfTestRepository testRepo = new SelfTestRepository();
                
                new UserDashboard(user, userRepository, moodRepo, journalRepo, testRepo).setVisible(true);
            } else {
                showErrorDialog("Invalid user credentials!");
            }
        });
        
        // Admin Login Action
        adminLoginBtn.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());
            
            if (adminRepository.validateAdmin(email, password)) {
                dispose();
                // Initialize repositories for admin dashboard
                MoodRepository moodRepo = new MoodRepository();
                JournalRepository journalRepo = new JournalRepository();
                new AdminDashboard(userRepository, moodRepo, journalRepo).setVisible(true);
            } else {
                showErrorDialog("Invalid admin credentials!");
            }
        });
        
        // Register Action
        registerBtn.addActionListener(e -> showRegisterDialog(emailField, passwordField));
        
        buttonPanel.add(userLoginBtn);
        buttonPanel.add(adminLoginBtn);
        buttonPanel.add(registerBtn);
        
        // Footer
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(BACKGROUND_COLOR);
        footerPanel.setLayout(new BoxLayout(footerPanel, BoxLayout.Y_AXIS));
        
        JButton resourceBtn = createTextButton("📚 Explore Resource Hub (Public Access)");
        resourceBtn.addActionListener(e -> new ResourceHub().setVisible(true));
        
        JLabel demoLabel = new JLabel("<html><center>Demo Admin: admin@mentalhealth.com / admin123<br>Demo User: user@example.com / password123</center></html>", JLabel.CENTER);
        demoLabel.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        demoLabel.setForeground(Color.GRAY);
        
        footerPanel.add(resourceBtn);
        footerPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        footerPanel.add(demoLabel);
        
        // Add all panels
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        JPanel container = new JPanel(new BorderLayout());
        container.add(mainPanel, BorderLayout.CENTER);
        container.add(footerPanel, BorderLayout.SOUTH);
        
        add(container);
    }
    
    private JPanel createInputField(String label, JComponent field) {
        JPanel panel = new JPanel(new BorderLayout(10, 5));
        panel.setBackground(BACKGROUND_COLOR);
        
        JLabel jLabel = new JLabel(label);
        jLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        jLabel.setForeground(new Color(75, 85, 99));
        
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(209, 213, 219)),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        
        panel.add(jLabel, BorderLayout.WEST);
        panel.add(field, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    private JButton createTextButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        button.setForeground(PRIMARY_COLOR);
        button.setBackground(BACKGROUND_COLOR);
        button.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setContentAreaFilled(false);
        
        return button;
    }
    
    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(this, 
            "<html><div style='text-align: center;'>" + message + "</div></html>", 
            "⚠️ Authentication Failed", 
            JOptionPane.ERROR_MESSAGE);
    }
    
    private void showRegisterDialog(JTextField emailField, JPasswordField passwordField) {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JTextField nameField = createStyledTextField();
        JTextField regEmailField = createStyledTextField();
        JPasswordField regPasswordField = new JPasswordField(20);
        regPasswordField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        regPasswordField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(209, 213, 219)),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(createInputLabel("👤 Full Name:"), gbc);
        gbc.gridx = 1;
        panel.add(nameField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(createInputLabel("📧 Email:"), gbc);
        gbc.gridx = 1;
        panel.add(regEmailField, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(createInputLabel("🔒 Password:"), gbc);
        gbc.gridx = 1;
        panel.add(regPasswordField, gbc);
        
        int result = JOptionPane.showConfirmDialog(this, panel, "✨ Create New Account", 
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            
        if (result == JOptionPane.OK_OPTION) {
            String name = nameField.getText();
            String email = regEmailField.getText();
            String password = new String(regPasswordField.getPassword());
            
            if (!name.isEmpty() && !email.isEmpty() && !password.isEmpty()) {
                // Check if email already exists in database
                if (userRepository.emailExists(email)) {
                    showErrorDialog("Email already registered!");
                } else {
                    // Create user in database
                    if (userRepository.createUser(name, email, password)) {
                        JOptionPane.showMessageDialog(this, 
                            "<html><div style='text-align: center;'>🎉 Registration successful!<br>You can now login with your new account.</div></html>",
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                        // Auto-fill the login form
                        emailField.setText(email);
                        passwordField.setText(password);
                    } else {
                        showErrorDialog("Registration failed! Please try again.");
                    }
                }
            } else {
                showErrorDialog("Please fill all fields!");
            }
        }
    }
    
    private JTextField createStyledTextField() {
        JTextField field = new JTextField(20);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(209, 213, 219)),
            BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        return field;
    }
    
    private JLabel createInputLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label.setForeground(new Color(75, 85, 99));
        return label;
    }
}