package mentalhealthapp;

import java.sql.*;
import java.util.*;

public class MoodRepository {
    private DatabaseConnection dbConnection;
    
    public MoodRepository() {
        this.dbConnection = new DatabaseConnection();
    }
    
    public boolean addMoodEntry(String userEmail, MoodEntry moodEntry) {
        String sql = "INSERT INTO mood_entries (user_id, date, mood, notes) " +
                    "VALUES ((SELECT user_id FROM users WHERE email = ?), ?, ?, ?)";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, userEmail);
            stmt.setString(2, moodEntry.getDate());
            stmt.setString(3, moodEntry.getMood());
            stmt.setString(4, moodEntry.getNotes());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public List<MoodEntry> getUserMoodHistory(String userEmail) {
        List<MoodEntry> moodHistory = new ArrayList<>();
        String sql = "SELECT me.* FROM mood_entries me " +
                    "JOIN users u ON me.user_id = u.user_id " +
                    "WHERE u.email = ? ORDER BY me.date DESC";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, userEmail);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                moodHistory.add(new MoodEntry(
                    rs.getString("date"),
                    rs.getString("mood"),
                    rs.getString("notes")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return moodHistory;
    }
    
    public List<Object[]> getAllMoodEntries() {
        List<Object[]> allMoods = new ArrayList<>();
        String sql = "SELECT u.name, u.email, me.date, me.mood, me.notes " +
                    "FROM mood_entries me " +
                    "JOIN users u ON me.user_id = u.user_id " +
                    "ORDER BY me.date DESC";
        
        try (Connection conn = dbConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                allMoods.add(new Object[]{
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("date"),
                    rs.getString("mood"),
                    rs.getString("notes")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allMoods;
    }
}