package mentalhealthapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ResourceHub extends JFrame {
    private final Color BACKGROUND_COLOR = new Color(245, 247, 255);
    private final Color CARD_COLOR = Color.WHITE;
    private final Color PRIMARY_COLOR = new Color(102, 126, 234);
    
    public ResourceHub() {
        setTitle("📚 Mental Health Resource Hub");
        setSize(800, 650);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BACKGROUND_COLOR);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(BACKGROUND_COLOR);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        // Header
        JLabel titleLabel = new JLabel("📚 Public Mental Health Resources", JLabel.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(PRIMARY_COLOR);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));
        
        // Content Panel
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(BACKGROUND_COLOR);
        
        // Emergency Section
        JPanel emergencyPanel = createSectionPanel("🆘 Crisis & Emergency Help", new Color(239, 68, 68));
        emergencyPanel.add(createResourceCard(
            "📞 National Suicide Prevention Lifeline", 
            "1-800-273-8255\nAvailable 24/7 for free and confidential support",
            new Color(254, 226, 226)
        ));
        emergencyPanel.add(createResourceCard(
            "💬 Crisis Text Line", 
            "Text HOME to 741741\nFree 24/7 crisis counseling via text",
            new Color(254, 226, 226)
        ));
        emergencyPanel.add(createResourceCard(
            "🏥 Emergency Services", 
            "911 or local emergency services\nFor immediate life-threatening situations",
            new Color(254, 226, 226)
        ));
        
        // Educational Resources Section
        JPanel educationPanel = createSectionPanel("📚 Educational Resources", new Color(59, 130, 246));
        educationPanel.add(createResourceCard(
            "🏛️ National Institute of Mental Health (NIMH)", 
            "Leading federal agency for mental health research\nwww.nimh.nih.gov",
            new Color(219, 234, 254)
        ));
        educationPanel.add(createResourceCard(
            "💙 Mental Health America (MHA)", 
            "Community-based nonprofit focused on mental health\nwww.mhanational.org",
            new Color(219, 234, 254)
        ));
        educationPanel.add(createResourceCard(
            "😰 Anxiety and Depression Association (ADAA)", 
            "Resources for anxiety, depression, and related disorders\nwww.adaa.org",
            new Color(219, 234, 254)
        ));
        
        // Tools & Apps Section
        JPanel toolsPanel = createSectionPanel("🆓 Free Tools & Apps", new Color(16, 185, 129));
        toolsPanel.add(createResourceCard(
            "🧘‍♀️ Meditation Apps", 
            "Headspace, Calm, Insight Timer\nGuided meditation and mindfulness",
            new Color(209, 250, 229)
        ));
        toolsPanel.add(createResourceCard(
            "📱 Mood Tracking Apps", 
            "Daylio, Moodpath, eMoods\nTrack your mood and identify patterns",
            new Color(209, 250, 229)
        ));
        toolsPanel.add(createResourceCard(
            "👥 Online Support Communities", 
            "7 Cups, Support Groups Central\nPeer support and community",
            new Color(209, 250, 229)
        ));
        
        // Self-Help Section
        JPanel selfHelpPanel = createSectionPanel("📖 Self-Help Guides", new Color(168, 85, 247));
        selfHelpPanel.add(createResourceCard(
            "🧠 Cognitive Behavioral Therapy", 
            "CBT worksheets and exercises\nChallenge negative thought patterns",
            new Color(237, 233, 254)
        ));
        selfHelpPanel.add(createResourceCard(
            "🌱 Mindfulness Exercises", 
            "Daily mindfulness practices\nStay present and reduce anxiety",
            new Color(237, 233, 254)
        ));
        selfHelpPanel.add(createResourceCard(
            "💪 Stress Management", 
            "Proven stress reduction techniques\nImprove coping skills",
            new Color(237, 233, 254)
        ));
        
        // Create tabbed pane for organized viewing
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        JScrollPane emergencyScroll = new JScrollPane(emergencyPanel);
        emergencyScroll.setBorder(BorderFactory.createEmptyBorder());
        tabbedPane.addTab("🆘 Emergency", emergencyScroll);
        
        JScrollPane educationScroll = new JScrollPane(educationPanel);
        educationScroll.setBorder(BorderFactory.createEmptyBorder());
        tabbedPane.addTab("📚 Education", educationScroll);
        
        JScrollPane toolsScroll = new JScrollPane(toolsPanel);
        toolsScroll.setBorder(BorderFactory.createEmptyBorder());
        tabbedPane.addTab("🆓 Tools", toolsScroll);
        
        JScrollPane selfHelpScroll = new JScrollPane(selfHelpPanel);
        selfHelpScroll.setBorder(BorderFactory.createEmptyBorder());
        tabbedPane.addTab("📖 Self-Help", selfHelpScroll);
        
        // Quick Tips Panel
        JPanel tipsPanel = createTipsPanel();
        
        // Action Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(BACKGROUND_COLOR);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        
        JButton printBtn = createStyledButton("🖨️ Print Resources", PRIMARY_COLOR);
        JButton saveBtn = createStyledButton("💾 Save as Reference", new Color(16, 185, 129));
        JButton closeBtn = createStyledButton("❌ Close Hub", new Color(239, 68, 68));
        
        printBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, 
                "📋 Resources ready for printing!\n\nYou can take screenshots or copy the information for your reference.",
                "Print Resources", JOptionPane.INFORMATION_MESSAGE);
        });
        
        saveBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, 
                "💾 Resources saved to your personal reference list!\n\nYou can access this information anytime from the Resource Hub.",
                "Save Successful", JOptionPane.INFORMATION_MESSAGE);
        });
        
        closeBtn.addActionListener(e -> dispose());
        
        buttonPanel.add(printBtn);
        buttonPanel.add(saveBtn);
        buttonPanel.add(closeBtn);
        
        // Add all components
        contentPanel.add(tabbedPane, BorderLayout.CENTER);
        contentPanel.add(tipsPanel, BorderLayout.SOUTH);
        
        mainPanel.add(titleLabel, BorderLayout.NORTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private JPanel createSectionPanel(String title, Color titleColor) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(titleColor);
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        panel.add(titleLabel);
        
        return panel;
    }
    
    private JPanel createResourceCard(String title, String description, Color bgColor) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(bgColor);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(229, 231, 235)),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        titleLabel.setForeground(new Color(55, 65, 81));
        
        JTextArea descArea = new JTextArea(description);
        descArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        descArea.setForeground(new Color(75, 85, 99));
        descArea.setBackground(bgColor);
        descArea.setEditable(false);
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        descArea.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
        
        // Info button for more details
        JButton infoBtn = new JButton("ℹ️");
        infoBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        infoBtn.setBackground(new Color(229, 231, 235));
        infoBtn.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        infoBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        infoBtn.addActionListener(e -> showResourceDetails(title, description));
        
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setBackground(bgColor);
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        titlePanel.add(infoBtn, BorderLayout.EAST);
        
        card.add(titlePanel, BorderLayout.NORTH);
        card.add(descArea, BorderLayout.CENTER);
        
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                showResourceDetails(title, description);
            }
            public void mouseEntered(MouseEvent e) {
                card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(PRIMARY_COLOR, 2),
                    BorderFactory.createEmptyBorder(14, 14, 14, 14)
                ));
            }
            public void mouseExited(MouseEvent e) {
                card.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(229, 231, 235)),
                    BorderFactory.createEmptyBorder(15, 15, 15, 15)
                ));
            }
        });
        
        return card;
    }
    
    private JPanel createTipsPanel() {
        JPanel tipsPanel = new JPanel(new BorderLayout());
        tipsPanel.setBackground(new Color(254, 252, 232));
        tipsPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("💡 Quick Mental Health Tips"),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        
        String tips = "• 🌅 Start your day with 5 minutes of mindfulness\n" +
                     "• 💧 Stay hydrated and take regular breaks\n" +
                     "• 📵 Limit screen time before bed\n" +
                     "• 🚶 Take short walks during the day\n" +
                     "• 📝 Practice gratitude journaling\n" +
                     "• 🎵 Listen to calming music\n" +
                     "• 🍎 Eat balanced meals regularly\n" +
                     "• 🛌 Maintain a consistent sleep schedule";
        
        JTextArea tipsArea = new JTextArea(tips);
        tipsArea.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tipsArea.setBackground(new Color(254, 252, 232));
        tipsArea.setEditable(false);
        tipsArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        tipsPanel.add(tipsArea, BorderLayout.CENTER);
        
        return tipsPanel;
    }
    
    private void showResourceDetails(String title, String description) {
        JPanel detailPanel = new JPanel(new BorderLayout());
        detailPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titleLabel.setForeground(PRIMARY_COLOR);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        
        JTextArea descArea = new JTextArea(description);
        descArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        descArea.setEditable(false);
        descArea.setBackground(new Color(249, 250, 251));
        
        // Add action buttons
        JPanel actionPanel = new JPanel(new FlowLayout());
        JButton copyBtn = new JButton("📋 Copy Info");
        JButton remindBtn = new JButton("⏰ Set Reminder");
        
        copyBtn.addActionListener(e -> {
            String copyText = title + "\n\n" + description;
            java.awt.datatransfer.StringSelection selection = new java.awt.datatransfer.StringSelection(copyText);
            java.awt.datatransfer.Clipboard clipboard = java.awt.Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(selection, selection);
            JOptionPane.showMessageDialog(this, "📋 Information copied to clipboard!", "Copied", JOptionPane.INFORMATION_MESSAGE);
        });
        
        remindBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, 
                "⏰ Reminder set!\n\nYou'll be reminded to check this resource tomorrow.",
                "Reminder Set", JOptionPane.INFORMATION_MESSAGE);
        });
        
        actionPanel.add(copyBtn);
        actionPanel.add(remindBtn);
        
        detailPanel.add(titleLabel, BorderLayout.NORTH);
        detailPanel.add(new JScrollPane(descArea), BorderLayout.CENTER);
        detailPanel.add(actionPanel, BorderLayout.SOUTH);
        
        JOptionPane.showMessageDialog(this, detailPanel, "🔍 Resource Details", JOptionPane.PLAIN_MESSAGE);
    }
    
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));
        button.setFocusPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    public static void main(String[] args) {
        // For testing purposes only
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new ResourceHub().setVisible(true);
        });
    }
}