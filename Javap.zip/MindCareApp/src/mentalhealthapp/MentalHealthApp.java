package mentalhealthapp;

import javax.swing.*;
import java.awt.*;

public class MentalHealthApp {
    public static void main(String[] args) {
        // Set modern look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> {
            // Initialize repositories
            UserRepository userRepository = new UserRepository();
            AdminRepository adminRepository = new AdminRepository();
            
            new LoginFrame(userRepository, adminRepository).setVisible(true);
        });
    }
}
