package mentalhealthapp;

import java.sql.*;
import java.util.*;

public class JournalRepository {
    private DatabaseConnection dbConnection;
    
    public JournalRepository() {
        this.dbConnection = new DatabaseConnection();
    }
    
    public boolean addJournalEntry(String userEmail, JournalEntry journalEntry) {
        String sql = "INSERT INTO journal_entries (user_id, date, title, content) " +
                    "VALUES ((SELECT user_id FROM users WHERE email = ?), ?, ?, ?)";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, userEmail);
            stmt.setString(2, journalEntry.getDate());
            stmt.setString(3, journalEntry.getTitle());
            stmt.setString(4, journalEntry.getContent());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public List<JournalEntry> getUserJournalEntries(String userEmail) {
        List<JournalEntry> journalEntries = new ArrayList<>();
        String sql = "SELECT je.* FROM journal_entries je " +
                    "JOIN users u ON je.user_id = u.user_id " +
                    "WHERE u.email = ? ORDER BY je.date DESC";
        
        try (Connection conn = dbConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, userEmail);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                journalEntries.add(new JournalEntry(
                    rs.getString("date"),
                    rs.getString("title"),
                    rs.getString("content")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return journalEntries;
    }
    
    public List<Object[]> getAllJournalEntries() {
        List<Object[]> allJournals = new ArrayList<>();
        String sql = "SELECT u.name, je.date, je.title, je.content " +
                    "FROM journal_entries je " +
                    "JOIN users u ON je.user_id = u.user_id " +
                    "ORDER BY je.date DESC";
        
        try (Connection conn = dbConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                String content = rs.getString("content");
                String preview = content.length() > 50 ? content.substring(0, 50) + "..." : content;
                allJournals.add(new Object[]{
                    rs.getString("name"),
                    rs.getString("date"),
                    rs.getString("title"),
                    preview
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allJournals;
    }
}